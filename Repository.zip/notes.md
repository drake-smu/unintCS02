# To do 

## Data stuff  

- [X] Factorize Columns
- [X] Graph frequency/summary to visualize dataset.
- [ ] Linear Regression stuff... (figure out after first 2)
- [ ] Permutation tests? Hypothesis testing? 